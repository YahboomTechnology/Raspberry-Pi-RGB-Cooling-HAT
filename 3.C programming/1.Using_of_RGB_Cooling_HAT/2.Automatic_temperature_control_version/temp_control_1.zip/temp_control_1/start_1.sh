#!/bin/sh
sleep 5s
cd /home/pi/temp_control_1/
./temp_control_1
