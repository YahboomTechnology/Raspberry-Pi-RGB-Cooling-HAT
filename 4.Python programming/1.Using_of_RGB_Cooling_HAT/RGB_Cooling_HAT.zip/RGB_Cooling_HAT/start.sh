#!/bin/sh
sleep 5s
sudo python3 /home/pi/RGB_Cooling_HAT/RGB_Cooling_HAT.py
